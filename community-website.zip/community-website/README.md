# 🌟 NovaCommunity — Modern Community Landing Page

Website landing page komunitas modern dengan dark mode glassmorphism, galeri media, dan sistem upload.

---

## ✨ Fitur

- **Beranda** — Hero banner full screen, statistik, fitur komunitas, galeri preview
- **Tentang Server** — Profil komunitas lengkap dengan logo dan banner
- **Galeri Media** — Upload foto/video, grid modern, lightbox, hapus media
- **Upload System** — Multer dengan validasi, auto-rename, size limit
- **Database SQLite** — Penyimpanan data ringan tanpa konfigurasi tambahan
- **Responsive** — Mobile-first, desktop friendly
- **Dark Mode** — Glassmorphism + gradient purple/cyan aesthetic

---

## 🚀 Cara Menjalankan

### 1. Install semua dependencies
```bash
npm run install:all
```

### 2. Jalankan development server
```bash
npm run dev
```

Frontend akan berjalan di: **http://localhost:5173**  
Backend akan berjalan di: **http://localhost:3001**

---

## ⚙️ Konfigurasi Komunitas

Edit file **`client/src/config.js`** untuk mengubah semua data komunitas:

```js
export const COMMUNITY_CONFIG = {
  name: "NomKomunitas",
  tagline: "Tagline kamu",
  description: "Deskripsi komunitas...",
  socials: {
    discord: "https://discord.gg/servermu",
    tiktok: "https://tiktok.com/@akun",
    // ...
  },
  // ...
}
```

Tidak perlu panel admin — semua diubah lewat file config ini.

---

## 📁 Struktur Folder

```
community-website/
├── client/                    # React + Vite frontend
│   ├── src/
│   │   ├── components/        # Navbar, Footer, dll
│   │   ├── pages/             # Home, About, Gallery
│   │   ├── styles/            # Global CSS + Tailwind
│   │   ├── config.js          # ← EDIT INI untuk data komunitas
│   │   └── App.jsx
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── server/                    # Node.js + Express backend
│   ├── src/
│   │   ├── routes/
│   │   │   └── gallery.js     # API upload & galeri
│   │   ├── uploads/           # File upload tersimpan di sini
│   │   ├── database/          # SQLite database file
│   │   ├── database.js        # Inisialisasi DB
│   │   └── server.js          # Entry point
│   └── .env                   # Konfigurasi environment
│
├── package.json               # Root scripts
└── README.md
```

---

## 🔌 API Endpoints

| Method | URL | Deskripsi |
|--------|-----|-----------|
| `GET` | `/api/gallery` | Ambil semua media |
| `GET` | `/api/gallery?type=image` | Filter by tipe |
| `GET` | `/api/gallery?limit=6` | Batasi jumlah |
| `POST` | `/api/gallery/upload` | Upload file baru |
| `DELETE` | `/api/gallery/:id` | Hapus media |
| `GET` | `/api/health` | Health check |

### Upload Request
```
POST /api/gallery/upload
Content-Type: multipart/form-data

media: <file>          # Required - gambar atau video
caption: "teks..."     # Optional - max 200 karakter
```

---

## 🗄️ Database Schema

```sql
CREATE TABLE gallery (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  type        TEXT NOT NULL,        -- 'image' atau 'video'
  filename    TEXT NOT NULL UNIQUE, -- nama file setelah rename
  caption     TEXT DEFAULT '',      -- caption opsional
  created_at  DATETIME DEFAULT ...  -- waktu upload
);
```

---

## 🎨 Kustomisasi Tampilan

- **Warna & Theme**: Edit `client/tailwind.config.js`
- **CSS Global**: Edit `client/src/styles/globals.css`
- **Font**: Ganti Google Fonts di `client/index.html`
- **Logo**: Ganti SVG di `client/src/components/Navbar.jsx`
- **Banner**: Set `COMMUNITY_CONFIG.bannerImage = "/banner.jpg"` dan taruh di `client/public/`

---

## 📦 Build Production

```bash
# Build frontend
npm run build

# Jalankan server (melayani static files otomatis)
cd server && NODE_ENV=production npm start
```

---

## 📝 Environment Variables (server/.env)

| Variable | Default | Deskripsi |
|----------|---------|-----------|
| `PORT` | 3001 | Port server |
| `MAX_IMAGE_SIZE_MB` | 10 | Maks ukuran gambar |
| `MAX_VIDEO_SIZE_MB` | 100 | Maks ukuran video |

---

Made with ❤️ for the community

const express = require('express')
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const { v4: uuidv4 } = require('uuid')
const db = require('../database')

const router = express.Router()

// ——— Upload directory ———
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true })
}

// ——— File type validation ———
const ALLOWED_IMAGE = ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
const ALLOWED_VIDEO = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime']
const MAX_IMAGE_MB = parseInt(process.env.MAX_IMAGE_SIZE_MB || '10')
const MAX_VIDEO_MB = parseInt(process.env.MAX_VIDEO_SIZE_MB || '100')

const fileFilter = (req, file, cb) => {
  const isImage = ALLOWED_IMAGE.includes(file.mimetype)
  const isVideo = ALLOWED_VIDEO.includes(file.mimetype)
  if (isImage || isVideo) {
    cb(null, true)
  } else {
    cb(new Error(`Tipe file tidak diizinkan: ${file.mimetype}`), false)
  }
}

// ——— Multer storage with auto-rename ———
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase()
    const unique = `${Date.now()}_${uuidv4().slice(0, 8)}${ext}`
    cb(null, unique)
  },
})

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: MAX_VIDEO_MB * 1024 * 1024, // use max (video), validate images separately
    files: 1,
  },
})

// ——— POST /api/gallery/upload ———
router.post('/upload', (req, res) => {
  upload.single('media')(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ success: false, message: `File terlalu besar. Maksimal ${MAX_VIDEO_MB}MB untuk video.` })
      }
      return res.status(400).json({ success: false, message: err.message })
    }
    if (err) {
      return res.status(400).json({ success: false, message: err.message })
    }
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'Tidak ada file yang diupload.' })
    }

    const isImage = ALLOWED_IMAGE.includes(req.file.mimetype)
    const type = isImage ? 'image' : 'video'

    // Check image-specific size limit
    if (isImage && req.file.size > MAX_IMAGE_MB * 1024 * 1024) {
      fs.unlink(req.file.path, () => {})
      return res.status(400).json({ success: false, message: `Gambar terlalu besar. Maksimal ${MAX_IMAGE_MB}MB.` })
    }

    const caption = (req.body.caption || '').slice(0, 200).trim()

    try {
      const stmt = db.prepare(`
        INSERT INTO gallery (type, filename, caption)
        VALUES (?, ?, ?)
      `)
      const result = stmt.run(type, req.file.filename, caption)

      const item = db.prepare('SELECT * FROM gallery WHERE id = ?').get(result.lastInsertRowid)

      return res.status(201).json({
        success: true,
        message: 'Upload berhasil!',
        item,
      })
    } catch (dbErr) {
      // Cleanup uploaded file on DB error
      fs.unlink(req.file.path, () => {})
      console.error('DB error:', dbErr)
      return res.status(500).json({ success: false, message: 'Gagal menyimpan ke database.' })
    }
  })
})

// ——— GET /api/gallery ———
router.get('/', (req, res) => {
  try {
    const type = req.query.type // 'image' | 'video' | undefined
    const limit = Math.min(parseInt(req.query.limit || '100'), 200)
    const offset = parseInt(req.query.offset || '0')

    let query = 'SELECT * FROM gallery'
    const params = []

    if (type && ['image', 'video'].includes(type)) {
      query += ' WHERE type = ?'
      params.push(type)
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'
    params.push(limit, offset)

    const items = db.prepare(query).all(...params)

    const total = type
      ? db.prepare('SELECT COUNT(*) as count FROM gallery WHERE type = ?').get(type).count
      : db.prepare('SELECT COUNT(*) as count FROM gallery').get().count

    return res.json({ success: true, items, total, limit, offset })
  } catch (err) {
    console.error('Gallery fetch error:', err)
    return res.status(500).json({ success: false, message: 'Gagal mengambil data galeri.' })
  }
})

// ——— GET /api/gallery/:id ———
router.get('/:id', (req, res) => {
  try {
    const item = db.prepare('SELECT * FROM gallery WHERE id = ?').get(req.params.id)
    if (!item) return res.status(404).json({ success: false, message: 'Media tidak ditemukan.' })
    return res.json({ success: true, item })
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Gagal mengambil data.' })
  }
})

// ——— DELETE /api/gallery/:id ———
router.delete('/:id', (req, res) => {
  try {
    const item = db.prepare('SELECT * FROM gallery WHERE id = ?').get(req.params.id)
    if (!item) return res.status(404).json({ success: false, message: 'Media tidak ditemukan.' })

    // Delete file from disk
    const filePath = path.join(UPLOAD_DIR, item.filename)
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath)
    }

    // Delete from DB
    db.prepare('DELETE FROM gallery WHERE id = ?').run(req.params.id)

    return res.json({ success: true, message: 'Media berhasil dihapus.' })
  } catch (err) {
    console.error('Delete error:', err)
    return res.status(500).json({ success: false, message: 'Gagal menghapus media.' })
  }
})

module.exports = router

require('dotenv').config()
const express = require('express')
const cors = require('cors')
const path = require('path')
const fs = require('fs')

const app = express()
const PORT = process.env.PORT || 3001

// ——— Middleware ———
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? false
    : ['http://localhost:5173', 'http://localhost:4173'],
  credentials: true,
}))

app.use(express.json({ limit: '1mb' }))
app.use(express.urlencoded({ extended: true, limit: '1mb' }))

// ——— Request logger (dev) ———
if (process.env.NODE_ENV !== 'production') {
  app.use((req, res, next) => {
    console.log(`${new Date().toISOString().slice(11, 19)} ${req.method} ${req.url}`)
    next()
  })
}

// ——— Static: uploads ———
const UPLOAD_DIR = path.join(__dirname, 'uploads')
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true })
}
app.use('/uploads', express.static(UPLOAD_DIR, {
  maxAge: '7d',
  etag: true,
}))

// ——— API Routes ———
app.use('/api/gallery', require('./routes/gallery'))

// ——— Health check ———
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
  })
})

// ——— Production: serve React build ———
if (process.env.NODE_ENV === 'production') {
  const clientBuild = path.join(__dirname, '..', '..', 'client', 'dist')
  if (fs.existsSync(clientBuild)) {
    app.use(express.static(clientBuild))
    app.get('*', (req, res) => {
      res.sendFile(path.join(clientBuild, 'index.html'))
    })
  }
}

// ——— 404 handler ———
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route tidak ditemukan.' })
})

// ——— Error handler ———
app.use((err, req, res, next) => {
  console.error('Server error:', err)
  res.status(500).json({
    success: false,
    message: process.env.NODE_ENV === 'production' ? 'Internal server error.' : err.message,
  })
})

// ——— Start ———
app.listen(PORT, () => {
  console.log('')
  console.log('  🚀 NovaCommunity Server')
  console.log(`  📡 Running on http://localhost:${PORT}`)
  console.log(`  📁 Uploads: ${UPLOAD_DIR}`)
  console.log(`  🌍 Environment: ${process.env.NODE_ENV}`)
  console.log('')
})

module.exports = app

const Database = require('better-sqlite3')
const path = require('path')
const fs = require('fs')

const DB_DIR = path.join(__dirname, '..', 'database')
const DB_PATH = path.join(DB_DIR, 'community.db')

// Ensure db directory exists
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true })
}

const db = new Database(DB_PATH)

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL')
db.pragma('foreign_keys = ON')

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS gallery (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    type      TEXT NOT NULL CHECK(type IN ('image', 'video')),
    filename  TEXT NOT NULL UNIQUE,
    caption   TEXT DEFAULT '',
    created_at DATETIME DEFAULT (datetime('now', 'localtime'))
  );

  CREATE INDEX IF NOT EXISTS idx_gallery_type ON gallery(type);
  CREATE INDEX IF NOT EXISTS idx_gallery_created ON gallery(created_at DESC);
`)

console.log('✅ Database initialized:', DB_PATH)

module.exports = db

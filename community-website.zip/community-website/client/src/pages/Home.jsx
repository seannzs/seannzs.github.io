import { useEffect, useState, useRef } from 'react'
import { Link } from 'react-router-dom'
import { COMMUNITY_CONFIG } from '../config'
import axios from 'axios'

// ——— Icons ———
const DiscordIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.1 18.084.118 18.11.135 18.12a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
  </svg>
)

const TikTokIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
    <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.67a8.16 8.16 0 004.77 1.52V6.74a4.85 4.85 0 01-1-.05z"/>
  </svg>
)

const ArrowIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M7 17L17 7M17 7H7M17 7v10"/>
  </svg>
)

const PlayIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <polygon points="5 3 19 12 5 21 5 3"/>
  </svg>
)

// ——— Animated particles ———
function Particles() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {Array.from({ length: 20 }).map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full"
          style={{
            width: Math.random() * 3 + 1 + 'px',
            height: Math.random() * 3 + 1 + 'px',
            left: Math.random() * 100 + '%',
            top: Math.random() * 100 + '%',
            background: i % 3 === 0 ? '#7c3aed' : i % 3 === 1 ? '#06b6d4' : '#a78bfa',
            opacity: Math.random() * 0.6 + 0.2,
            animation: `float ${Math.random() * 4 + 4}s ease-in-out ${Math.random() * 4}s infinite`,
          }}
        />
      ))}
    </div>
  )
}

// ——— Stat Card ———
function StatCard({ stat, index }) {
  const [visible, setVisible] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => e.isIntersecting && setVisible(true), { threshold: 0.3 })
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  return (
    <div
      ref={ref}
      className="glass-card p-6 text-center"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(30px)',
        transition: `all 0.6s cubic-bezier(0.23,1,0.32,1) ${index * 0.1}s`,
      }}
    >
      <div className="text-3xl mb-2">{stat.icon}</div>
      <div className="stat-number">{stat.value}</div>
      <div className="text-dim text-sm font-body mt-1">{stat.label}</div>
    </div>
  )
}

// ——— Feature Card ———
function FeatureCard({ feature, index }) {
  const [visible, setVisible] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => e.isIntersecting && setVisible(true), { threshold: 0.2 })
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  return (
    <div
      ref={ref}
      className="glass-card glass-card-hover p-6"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(40px)',
        transition: `all 0.7s cubic-bezier(0.23,1,0.32,1) ${index * 0.12}s`,
      }}
    >
      <div className="text-4xl mb-4">{feature.icon}</div>
      <h3 className="font-display font-bold text-lg text-white mb-2">{feature.title}</h3>
      <p className="text-dim text-sm leading-relaxed">{feature.desc}</p>
    </div>
  )
}

// ——— Gallery Preview Item ———
function GalleryPreviewItem({ item }) {
  const isVideo = item.type === 'video'
  const src = `/uploads/${item.filename}`

  return (
    <div className="media-grid-item group">
      {isVideo ? (
        <>
          <video src={src} className="w-full h-full object-cover" muted />
          <div className="absolute inset-0 flex items-center justify-center z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <PlayIcon />
            </div>
          </div>
        </>
      ) : (
        <img src={src} alt={item.caption || ''} className="w-full h-full object-cover" loading="lazy" />
      )}
      {item.caption && (
        <div className="absolute bottom-0 left-0 right-0 p-3 z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <p className="text-white text-xs font-medium truncate">{item.caption}</p>
        </div>
      )}
    </div>
  )
}

// ——— Main Home Page ———
export default function Home() {
  const [galleryPreview, setGalleryPreview] = useState([])
  const [heroReady, setHeroReady] = useState(false)
  const { name, tagline, description, cta, stats, features, tags, heroVideo } = COMMUNITY_CONFIG

  useEffect(() => {
    setTimeout(() => setHeroReady(true), 100)
    axios.get('/api/gallery?limit=6').then(r => setGalleryPreview(r.data.items || [])).catch(() => {})
  }, [])

  return (
    <div className="relative">

      {/* ——— HERO ——— */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0">
          {heroVideo ? (
            <video autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover opacity-30">
              <source src={heroVideo} type="video/mp4" />
            </video>
          ) : null}
          {/* Gradient base */}
          <div className="absolute inset-0 bg-hero-gradient" />
          {/* Orbs */}
          <div className="orb w-[600px] h-[600px] -top-32 -left-32 bg-accent-violet/20 animate-pulse-slow" />
          <div className="orb w-[500px] h-[500px] -bottom-20 -right-20 bg-accent-cyan/15 animate-pulse-slow" style={{ animationDelay: '2s' }} />
          <div className="orb w-72 h-72 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-accent-fuchsia/10" />
          {/* Grid overlay */}
          <div
            className="absolute inset-0 opacity-5"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: '60px 60px',
            }}
          />
          <Particles />
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
          {/* Section label */}
          <div
            className="flex justify-center mb-8"
            style={{ opacity: heroReady ? 1 : 0, transform: heroReady ? 'translateY(0)' : 'translateY(-20px)', transition: 'all 0.8s ease 0.2s' }}
          >
            <span className="section-label">
              <span className="glow-dot" />
              Server Aktif
            </span>
          </div>

          {/* Tags */}
          <div
            className="flex flex-wrap justify-center gap-2 mb-8"
            style={{ opacity: heroReady ? 1 : 0, transition: 'all 0.8s ease 0.3s' }}
          >
            {tags.map(tag => (
              <span key={tag} className="tag-badge">{tag}</span>
            ))}
          </div>

          {/* Title */}
          <h1
            className="hero-title text-6xl sm:text-7xl md:text-8xl lg:text-9xl text-white mb-6"
            style={{ opacity: heroReady ? 1 : 0, transform: heroReady ? 'translateY(0)' : 'translateY(40px)', transition: 'all 0.9s cubic-bezier(0.23,1,0.32,1) 0.4s' }}
          >
            <span className="block text-gradient">{name}</span>
          </h1>

          {/* Tagline */}
          <p
            className="font-display font-semibold text-xl sm:text-2xl md:text-3xl text-white/60 mb-6 tracking-wide"
            style={{ opacity: heroReady ? 1 : 0, transform: heroReady ? 'translateY(0)' : 'translateY(30px)', transition: 'all 0.9s cubic-bezier(0.23,1,0.32,1) 0.5s' }}
          >
            {tagline}
          </p>

          {/* Description */}
          <p
            className="text-mid text-base sm:text-lg max-w-2xl mx-auto mb-12 leading-relaxed"
            style={{ opacity: heroReady ? 1 : 0, transform: heroReady ? 'translateY(0)' : 'translateY(30px)', transition: 'all 0.9s cubic-bezier(0.23,1,0.32,1) 0.6s' }}
          >
            {description}
          </p>

          {/* CTAs */}
          <div
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-20"
            style={{ opacity: heroReady ? 1 : 0, transform: heroReady ? 'translateY(0)' : 'translateY(30px)', transition: 'all 0.9s cubic-bezier(0.23,1,0.32,1) 0.7s' }}
          >
            <a href={cta.primary.href} target="_blank" rel="noopener noreferrer" className="btn-primary flex items-center gap-2.5 text-white">
              <DiscordIcon />
              <span>{cta.primary.label}</span>
            </a>
            <a href={cta.secondary.href} target="_blank" rel="noopener noreferrer" className="btn-secondary flex items-center gap-2.5">
              <TikTokIcon />
              <span>{cta.secondary.label}</span>
            </a>
          </div>

          {/* Scroll indicator */}
          <div
            className="flex justify-center"
            style={{ opacity: heroReady ? 0.4 : 0, transition: 'opacity 1.2s ease 1.2s' }}
          >
            <div className="flex flex-col items-center gap-2 animate-bounce">
              <span className="text-xs font-mono text-dim tracking-widest uppercase">Scroll</span>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-dim">
                <path d="M12 5v14M5 12l7 7 7-7"/>
              </svg>
            </div>
          </div>
        </div>
      </section>

      {/* ——— STATS ——— */}
      <section className="relative py-20 overflow-hidden">
        <div className="orb w-96 h-96 top-0 left-1/2 -translate-x-1/2 bg-accent-violet/10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((stat, i) => (
              <StatCard key={i} stat={stat} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* ——— FEATURES ——— */}
      <section className="relative py-24 overflow-hidden">
        <div className="orb w-[500px] h-[500px] top-0 right-0 bg-accent-cyan/8" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="section-label mb-6 inline-flex">Kenapa Bergabung?</span>
            <h2 className="font-display font-bold text-4xl md:text-5xl text-white mt-6">
              Lebih dari sekadar{' '}
              <span className="text-gradient">komunitas</span>
            </h2>
            <p className="text-dim text-lg mt-4 max-w-xl mx-auto">
              Kami menyediakan ekosistem lengkap untuk kamu berkembang dan berkarya.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {features.map((feature, i) => (
              <FeatureCard key={i} feature={feature} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* ——— GALLERY PREVIEW ——— */}
      <section className="relative py-24 overflow-hidden">
        <div className="orb w-96 h-96 bottom-0 left-0 bg-accent-fuchsia/10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-12 gap-4">
            <div>
              <span className="section-label mb-4 inline-flex">Galeri Terbaru</span>
              <h2 className="font-display font-bold text-3xl md:text-4xl text-white mt-4">
                Momen <span className="text-gradient">terbaik</span> komunitas
              </h2>
            </div>
            <Link
              to="/gallery"
              className="flex items-center gap-2 text-sm font-semibold text-accent-violet hover:text-accent-cyan transition-colors duration-200 whitespace-nowrap group"
            >
              Lihat Semua
              <span className="group-hover:translate-x-1 transition-transform duration-200"><ArrowIcon /></span>
            </Link>
          </div>

          {galleryPreview.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {galleryPreview.map((item) => (
                <GalleryPreviewItem key={item.id} item={item} />
              ))}
            </div>
          ) : (
            <div className="glass-card p-16 text-center">
              <div className="text-5xl mb-4">📸</div>
              <p className="font-display font-semibold text-lg text-white mb-2">Galeri Masih Kosong</p>
              <p className="text-dim text-sm mb-6">Upload media pertama komunitas kamu di halaman galeri.</p>
              <Link to="/gallery" className="btn-primary inline-flex">Buka Galeri</Link>
            </div>
          )}
        </div>
      </section>

      {/* ——— BOTTOM CTA ——— */}
      <section className="relative py-32 overflow-hidden">
        <div className="orb w-[700px] h-[400px] top-0 left-1/2 -translate-x-1/2 bg-accent-violet/15" />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="glass-card p-12 md:p-16 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-accent-violet/10 to-accent-cyan/5" />
            <div className="relative">
              <h2 className="hero-title text-4xl sm:text-5xl md:text-6xl text-white mb-6">
                Siap untuk <span className="text-gradient">bergabung?</span>
              </h2>
              <p className="text-mid text-lg mb-10 max-w-lg mx-auto">
                Jadilah bagian dari ribuan member yang sudah bergabung dan rasakan pengalaman komunitas yang berbeda.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a href={cta.primary.href} target="_blank" rel="noopener noreferrer" className="btn-primary flex items-center gap-2.5 text-white">
                  <DiscordIcon />
                  <span>Join Discord Sekarang</span>
                </a>
                <a href={cta.secondary.href} target="_blank" rel="noopener noreferrer" className="btn-secondary flex items-center gap-2.5">
                  <TikTokIcon />
                  <span>Follow TikTok</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

import { useState, useEffect, useRef, useCallback } from 'react'
import axios from 'axios'

// ——— Icons ———
const UploadIcon = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/>
  </svg>
)

const CloseIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
  </svg>
)

const PlayIcon = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
    <polygon points="5 3 19 12 5 21 5 3"/>
  </svg>
)

const ChevronLeft = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="15 18 9 12 15 6"/>
  </svg>
)

const ChevronRight = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="9 18 15 12 9 6"/>
  </svg>
)

const ImageIcon = () => (
  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="text-dim">
    <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>
    <polyline points="21 15 16 10 5 21"/>
  </svg>
)

const CheckIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
)

const TrashIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
  </svg>
)

// ——— Upload Panel ———
function UploadPanel({ onUploaded }) {
  const [dragging, setDragging] = useState(false)
  const [file, setFile] = useState(null)
  const [caption, setCaption] = useState('')
  const [uploading, setUploading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')
  const [preview, setPreview] = useState(null)
  const inputRef = useRef(null)

  const handleFile = (f) => {
    if (!f) return
    const isImage = f.type.startsWith('image/')
    const isVideo = f.type.startsWith('video/')
    if (!isImage && !isVideo) { setError('Hanya file gambar atau video yang diizinkan.'); return }
    const maxMb = isVideo ? 100 : 10
    if (f.size > maxMb * 1024 * 1024) { setError(`Ukuran file maksimal ${maxMb}MB.`); return }
    setError('')
    setFile(f)
    setPreview(URL.createObjectURL(f))
  }

  const onDrop = useCallback((e) => {
    e.preventDefault()
    setDragging(false)
    handleFile(e.dataTransfer.files[0])
  }, [])

  const onDragOver = (e) => { e.preventDefault(); setDragging(true) }
  const onDragLeave = () => setDragging(false)

  const handleUpload = async () => {
    if (!file) return
    setUploading(true)
    setError('')
    try {
      const form = new FormData()
      form.append('media', file)
      form.append('caption', caption)
      await axios.post('/api/gallery/upload', form, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      setSuccess(true)
      setFile(null)
      setCaption('')
      setPreview(null)
      onUploaded()
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err.response?.data?.message || 'Upload gagal. Coba lagi.')
    } finally {
      setUploading(false)
    }
  }

  const clearFile = () => { setFile(null); setPreview(null); setError('') }

  return (
    <div className="glass-card p-6 md:p-8">
      <h3 className="font-display font-bold text-lg text-white mb-6 flex items-center gap-2">
        <UploadIcon />
        Upload Media
      </h3>

      {/* Drop Zone */}
      {!file ? (
        <div
          className={`upload-zone p-10 text-center cursor-pointer ${dragging ? 'drag-over' : ''}`}
          onDrop={onDrop}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onClick={() => inputRef.current?.click()}
        >
          <input
            ref={inputRef}
            type="file"
            accept="image/*,video/*"
            className="hidden"
            onChange={(e) => handleFile(e.target.files[0])}
          />
          <div className="flex justify-center mb-4 text-accent-violet/60">
            <UploadIcon />
          </div>
          <p className="font-display font-semibold text-white mb-1">Drop file di sini</p>
          <p className="text-dim text-sm">atau klik untuk memilih file</p>
          <p className="text-xs text-dim mt-4 font-mono">JPG, PNG, GIF, MP4, WEBM · Max 10MB (video: 100MB)</p>
        </div>
      ) : (
        <div className="relative rounded-xl overflow-hidden bg-surface-2 mb-4">
          {file.type.startsWith('image/') ? (
            <img src={preview} alt="Preview" className="w-full h-48 object-cover" />
          ) : (
            <video src={preview} className="w-full h-48 object-cover" muted />
          )}
          <button
            onClick={clearFile}
            className="absolute top-3 right-3 w-8 h-8 rounded-full bg-void/80 backdrop-blur-sm flex items-center justify-center hover:bg-void transition-colors"
          >
            <CloseIcon />
          </button>
          <div className="absolute bottom-3 left-3">
            <span className="tag-badge">{file.type.startsWith('image/') ? '🖼 Gambar' : '🎬 Video'}</span>
          </div>
        </div>
      )}

      {/* Caption */}
      <div className="mt-4">
        <input
          type="text"
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder="Caption (opsional)..."
          className="w-full px-4 py-3 rounded-xl text-sm font-body text-white placeholder:text-dim focus:outline-none focus:border-accent-violet/50 transition-colors"
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
          maxLength={200}
        />
      </div>

      {/* Error */}
      {error && (
        <p className="text-red-400 text-sm mt-3 font-mono flex items-center gap-2">
          <span>⚠</span> {error}
        </p>
      )}

      {/* Success */}
      {success && (
        <div className="mt-3 px-4 py-3 rounded-xl flex items-center gap-2 text-sm text-green-300" style={{ background: 'rgba(74,222,128,0.08)', border: '1px solid rgba(74,222,128,0.2)' }}>
          <CheckIcon />
          <span>Upload berhasil! Media ditambahkan ke galeri.</span>
        </div>
      )}

      {/* Upload button */}
      <button
        onClick={handleUpload}
        disabled={!file || uploading}
        className={`btn-primary w-full mt-4 flex items-center justify-center gap-2 text-white ${!file || uploading ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        {uploading ? (
          <>
            <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" strokeDasharray="60" strokeDashoffset="15"/>
            </svg>
            <span>Mengupload...</span>
          </>
        ) : (
          <>
            <UploadIcon />
            <span>Upload Media</span>
          </>
        )}
      </button>
    </div>
  )
}

// ——— Lightbox ———
function Lightbox({ items, activeIndex, onClose, onPrev, onNext }) {
  const item = items[activeIndex]
  if (!item) return null

  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowLeft') onPrev()
      if (e.key === 'ArrowRight') onNext()
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [onClose, onPrev, onNext])

  const src = `/uploads/${item.filename}`

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center" onClick={onClose}>
      {/* Backdrop */}
      <div className="absolute inset-0 bg-void/95 backdrop-blur-2xl" />

      {/* Controls */}
      <button
        onClick={(e) => { e.stopPropagation(); onClose() }}
        className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full glass-card flex items-center justify-center hover:bg-white/10 transition-colors"
      >
        <CloseIcon />
      </button>

      {activeIndex > 0 && (
        <button
          onClick={(e) => { e.stopPropagation(); onPrev() }}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-10 w-12 h-12 rounded-full glass-card flex items-center justify-center hover:bg-white/10 transition-colors"
        >
          <ChevronLeft />
        </button>
      )}

      {activeIndex < items.length - 1 && (
        <button
          onClick={(e) => { e.stopPropagation(); onNext() }}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-10 w-12 h-12 rounded-full glass-card flex items-center justify-center hover:bg-white/10 transition-colors"
        >
          <ChevronRight />
        </button>
      )}

      {/* Media */}
      <div
        className="relative z-10 max-w-5xl max-h-[85vh] w-full mx-4"
        onClick={(e) => e.stopPropagation()}
      >
        {item.type === 'video' ? (
          <video
            src={src}
            controls
            autoPlay
            className="w-full max-h-[80vh] rounded-xl object-contain"
            style={{ boxShadow: '0 0 80px rgba(0,0,0,0.8)' }}
          />
        ) : (
          <img
            src={src}
            alt={item.caption || ''}
            className="w-full max-h-[80vh] rounded-xl object-contain"
            style={{ boxShadow: '0 0 80px rgba(0,0,0,0.8)' }}
          />
        )}
        {item.caption && (
          <div className="mt-4 text-center">
            <p className="text-mid text-sm">{item.caption}</p>
          </div>
        )}
        <div className="mt-2 text-center">
          <span className="text-dim text-xs font-mono">{activeIndex + 1} / {items.length}</span>
        </div>
      </div>
    </div>
  )
}

// ——— Gallery Item ———
function GalleryItem({ item, index, onClick, onDelete }) {
  const [visible, setVisible] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => e.isIntersecting && setVisible(true), { threshold: 0.1 })
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  const src = `/uploads/${item.filename}`
  const isVideo = item.type === 'video'
  const date = new Date(item.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })

  const handleDelete = async (e) => {
    e.stopPropagation()
    if (!confirm('Hapus media ini?')) return
    try {
      await axios.delete(`/api/gallery/${item.id}`)
      onDelete(item.id)
    } catch {
      alert('Gagal menghapus media.')
    }
  }

  return (
    <div
      ref={ref}
      className="media-grid-item group"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'scale(1)' : 'scale(0.95)',
        transition: `all 0.5s cubic-bezier(0.23,1,0.32,1) ${(index % 6) * 0.07}s`,
      }}
      onClick={onClick}
    >
      {isVideo ? (
        <>
          <video src={src} className="w-full h-full object-cover" muted />
          <div className="absolute inset-0 flex items-center justify-center z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <PlayIcon />
            </div>
          </div>
        </>
      ) : (
        <img src={src} alt={item.caption || ''} className="w-full h-full object-cover" loading="lazy" />
      )}

      {/* Overlay */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-20" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.3) 50%, transparent 100%)' }}>
        <div className="absolute bottom-0 left-0 right-0 p-3">
          {item.caption && (
            <p className="text-white text-xs font-medium truncate mb-1">{item.caption}</p>
          )}
          <div className="flex items-center justify-between">
            <span className="text-white/50 text-xs font-mono">{date}</span>
            <button
              onClick={handleDelete}
              className="w-7 h-7 rounded-lg bg-red-500/20 hover:bg-red-500/60 flex items-center justify-center transition-colors"
            >
              <TrashIcon />
            </button>
          </div>
        </div>
        {isVideo && (
          <div className="absolute top-3 right-3">
            <span className="tag-badge text-[10px] py-0.5">VIDEO</span>
          </div>
        )}
      </div>
    </div>
  )
}

// ——— Skeleton Loader ———
function SkeletonItem() {
  return (
    <div
      className="rounded-xl overflow-hidden"
      style={{ aspectRatio: '1', background: 'linear-gradient(90deg, rgba(255,255,255,0.04) 25%, rgba(255,255,255,0.08) 50%, rgba(255,255,255,0.04) 75%)', backgroundSize: '200% 100%', animation: 'shimmer 1.5s linear infinite' }}
    />
  )
}

// ——— Main Gallery Page ———
export default function Gallery() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [lightboxIndex, setLightboxIndex] = useState(null)
  const [showUpload, setShowUpload] = useState(false)

  const fetchGallery = async () => {
    try {
      const r = await axios.get('/api/gallery')
      setItems(r.data.items || [])
    } catch {
      setItems([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchGallery() }, [])

  const filtered = filter === 'all' ? items : items.filter(i => i.type === filter)

  const handleDelete = (id) => setItems(prev => prev.filter(i => i.id !== id))

  const handleUploaded = () => { fetchGallery(); setShowUpload(false) }

  return (
    <div className="relative pt-16">
      {/* Header */}
      <div className="relative overflow-hidden py-24 border-b border-glass-border">
        <div className="orb w-[500px] h-[500px] -top-40 right-0 bg-accent-cyan/10" />
        <div className="orb w-96 h-96 -top-20 -left-20 bg-accent-violet/12" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <span className="section-label mb-6 inline-flex animate-reveal">Galeri Media</span>
          <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6 mt-6">
            <div>
              <h1 className="hero-title text-5xl md:text-7xl text-white animate-reveal delay-100">
                Momen <span className="text-gradient">komunitas</span>
              </h1>
              <p className="text-mid text-lg mt-4 animate-reveal delay-200">
                Koleksi foto dan video terbaik dari komunitas kami.
              </p>
            </div>
            <button
              onClick={() => setShowUpload(!showUpload)}
              className={`btn-primary flex items-center gap-2.5 text-white whitespace-nowrap ${showUpload ? 'opacity-70' : ''}`}
            >
              <UploadIcon />
              <span>{showUpload ? 'Tutup Upload' : 'Upload Media'}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">

        {/* Upload panel */}
        {showUpload && (
          <div className="mb-10 animate-reveal">
            <UploadPanel onUploaded={handleUploaded} />
          </div>
        )}

        {/* Filter tabs */}
        <div className="flex items-center gap-3 mb-8">
          {[
            { key: 'all', label: 'Semua', count: items.length },
            { key: 'image', label: 'Foto', count: items.filter(i => i.type === 'image').length },
            { key: 'video', label: 'Video', count: items.filter(i => i.type === 'video').length },
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 flex items-center gap-2 ${
                filter === tab.key
                  ? 'bg-accent-violet text-white shadow-glow-violet'
                  : 'glass-card text-dim hover:text-white'
              }`}
            >
              {tab.label}
              <span className={`text-xs px-1.5 py-0.5 rounded-full ${filter === tab.key ? 'bg-white/20' : 'bg-white/5'}`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {Array.from({ length: 8 }).map((_, i) => <SkeletonItem key={i} />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="glass-card p-20 text-center">
            <div className="flex justify-center mb-4 opacity-30">
              <ImageIcon />
            </div>
            <h3 className="font-display font-bold text-xl text-white mb-2">
              {filter === 'all' ? 'Galeri Masih Kosong' : `Belum ada ${filter === 'image' ? 'foto' : 'video'}`}
            </h3>
            <p className="text-dim text-sm mb-6">
              {filter === 'all'
                ? 'Upload foto atau video pertama komunitas kamu!'
                : `Upload ${filter === 'image' ? 'foto' : 'video'} untuk melihatnya di sini.`}
            </p>
            <button
              onClick={() => setShowUpload(true)}
              className="btn-primary inline-flex items-center gap-2 text-white"
            >
              <UploadIcon />
              <span>Upload Sekarang</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {filtered.map((item, i) => (
              <GalleryItem
                key={item.id}
                item={item}
                index={i}
                onClick={() => setLightboxIndex(i)}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}

        {/* Item count */}
        {filtered.length > 0 && (
          <p className="text-center text-dim text-xs font-mono mt-8">
            Menampilkan {filtered.length} dari {items.length} media
          </p>
        )}
      </div>

      {/* Lightbox */}
      {lightboxIndex !== null && (
        <Lightbox
          items={filtered}
          activeIndex={lightboxIndex}
          onClose={() => setLightboxIndex(null)}
          onPrev={() => setLightboxIndex(i => Math.max(0, i - 1))}
          onNext={() => setLightboxIndex(i => Math.min(filtered.length - 1, i + 1))}
        />
      )}
    </div>
  )
}

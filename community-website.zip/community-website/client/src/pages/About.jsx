import { useEffect, useRef, useState } from 'react'
import { COMMUNITY_CONFIG } from '../config'

function RevealBlock({ children, delay = 0 }) {
  const [visible, setVisible] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => e.isIntersecting && setVisible(true), { threshold: 0.15 })
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  return (
    <div
      ref={ref}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(40px)',
        transition: `all 0.8s cubic-bezier(0.23,1,0.32,1) ${delay}s`,
      }}
    >
      {children}
    </div>
  )
}

const DiscordIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.1 18.084.118 18.11.135 18.12a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
  </svg>
)

const TikTokIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
    <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.67a8.16 8.16 0 004.77 1.52V6.74a4.85 4.85 0 01-1-.05z"/>
  </svg>
)

// Community logo placeholder SVG
function CommunityLogo() {
  return (
    <div className="relative">
      <div className="w-32 h-32 md:w-40 md:h-40 rounded-2xl overflow-hidden relative" style={{ boxShadow: '0 0 60px rgba(124,58,237,0.5)' }}>
        <div className="absolute inset-0 bg-gradient-to-br from-accent-violet via-accent-indigo to-accent-cyan" />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-display font-black text-white" style={{ fontSize: '4rem', lineHeight: 1 }}>N</span>
        </div>
        <div className="absolute inset-0 border-2 border-white/10 rounded-2xl" />
      </div>
      {/* Status badge */}
      <div className="absolute -bottom-3 -right-3 glass-card px-3 py-1.5 flex items-center gap-2">
        <span className="glow-dot" />
        <span className="text-xs font-mono text-white">Online</span>
      </div>
    </div>
  )
}

// Community banner placeholder
function CommunityBanner({ bannerImage }) {
  if (bannerImage) {
    return (
      <div className="w-full h-48 md:h-64 rounded-2xl overflow-hidden">
        <img src={bannerImage} alt="Banner komunitas" className="w-full h-full object-cover" />
      </div>
    )
  }

  return (
    <div className="w-full h-48 md:h-64 rounded-2xl overflow-hidden relative">
      <div className="absolute inset-0 bg-gradient-to-r from-accent-violet/40 via-accent-indigo/30 to-accent-cyan/30" />
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: '40px 40px',
        }}
      />
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <p className="font-display font-black text-white/30 text-6xl md:text-8xl tracking-tighter select-none">
          NOVA
        </p>
      </div>
      <div className="absolute inset-0 border border-white/10 rounded-2xl" />
    </div>
  )
}

export default function About() {
  const { name, shortBio, description, stats, features, socials, tags, bannerImage } = COMMUNITY_CONFIG

  return (
    <div className="relative pt-16">
      {/* Page header */}
      <div className="relative overflow-hidden py-24 border-b border-glass-border">
        <div className="orb w-[500px] h-[500px] -top-40 -left-40 bg-accent-violet/15" />
        <div className="orb w-96 h-96 -top-20 right-0 bg-accent-cyan/10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-reveal">
            <span className="section-label mb-6 inline-flex">Tentang Server</span>
          </div>
          <h1 className="hero-title text-5xl md:text-7xl text-white mt-6 animate-reveal delay-100">
            Kenal lebih dekat<br />
            dengan <span className="text-gradient">{name}</span>
          </h1>
          <p className="text-mid text-lg mt-6 max-w-2xl animate-reveal delay-200">
            {shortBio}
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">

        {/* Profile Section */}
        <RevealBlock>
          <div className="glass-card p-8 md:p-12 mb-12">
            {/* Banner */}
            <CommunityBanner bannerImage={bannerImage} />

            {/* Profile info */}
            <div className="flex flex-col md:flex-row items-start md:items-end gap-8 mt-6">
              <div className="-mt-12 md:-mt-16 ml-0 md:ml-6">
                <CommunityLogo />
              </div>
              <div className="flex-1">
                <h2 className="font-display font-bold text-3xl text-white mb-1">{name}</h2>
                <div className="flex flex-wrap gap-2 mt-3">
                  {tags.map(tag => (
                    <span key={tag} className="tag-badge">{tag}</span>
                  ))}
                </div>
              </div>
              <a
                href={socials.discord}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary flex items-center gap-2.5 text-white whitespace-nowrap"
              >
                <DiscordIcon />
                <span>Join Server</span>
              </a>
            </div>
          </div>
        </RevealBlock>

        {/* Bio Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <RevealBlock delay={0.1}>
            <div className="lg:col-span-2 glass-card p-8">
              <h3 className="font-display font-bold text-xl text-white mb-4 flex items-center gap-2">
                <span className="text-accent-violet">#</span> Bio Komunitas
              </h3>
              <p className="text-mid leading-relaxed">{description}</p>
              <p className="text-mid leading-relaxed mt-4">{shortBio}</p>
              <div className="mt-6 pt-6 border-t border-glass-border">
                <a
                  href={socials.tiktok}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary inline-flex items-center gap-2"
                >
                  <TikTokIcon />
                  <span>Follow TikTok Kami</span>
                </a>
              </div>
            </div>
          </RevealBlock>

          <RevealBlock delay={0.2}>
            <div className="glass-card p-8">
              <h3 className="font-display font-bold text-xl text-white mb-6 flex items-center gap-2">
                <span className="text-accent-cyan">#</span> Statistik
              </h3>
              <div className="space-y-5">
                {stats.map((stat, i) => (
                  <div key={i} className="flex items-center gap-4">
                    <span className="text-2xl">{stat.icon}</span>
                    <div>
                      <div className="font-display font-bold text-2xl text-white leading-none">{stat.value}</div>
                      <div className="text-dim text-xs mt-0.5">{stat.label}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </RevealBlock>
        </div>

        {/* Features / What We Offer */}
        <RevealBlock delay={0.1}>
          <div className="mb-12">
            <div className="flex items-center gap-3 mb-8">
              <h3 className="font-display font-bold text-2xl text-white">Apa yang kami tawarkan</h3>
              <div className="flex-1 h-px bg-gradient-to-r from-glass-border to-transparent" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {features.map((f, i) => (
                <RevealBlock key={i} delay={i * 0.1}>
                  <div className="glass-card glass-card-hover p-6 flex items-start gap-4">
                    <span className="text-3xl flex-shrink-0">{f.icon}</span>
                    <div>
                      <h4 className="font-display font-bold text-white mb-1">{f.title}</h4>
                      <p className="text-dim text-sm leading-relaxed">{f.desc}</p>
                    </div>
                  </div>
                </RevealBlock>
              ))}
            </div>
          </div>
        </RevealBlock>

        {/* Social Links */}
        <RevealBlock delay={0.2}>
          <div className="glass-card p-8">
            <h3 className="font-display font-bold text-xl text-white mb-6 flex items-center gap-2">
              <span className="text-accent-violet">#</span> Temukan Kami
            </h3>
            <div className="flex flex-wrap gap-4">
              {Object.entries(socials).map(([platform, href]) => (
                <a
                  key={platform}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="glass-card glass-card-hover px-5 py-3 flex items-center gap-2 capitalize text-sm font-medium text-mid hover:text-white"
                >
                  <span className="text-accent-violet">↗</span>
                  {platform}
                </a>
              ))}
            </div>
          </div>
        </RevealBlock>

      </div>
    </div>
  )
}

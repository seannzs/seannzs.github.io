// ============================================================
// KONFIGURASI KOMUNITAS — Edit semua data komunitas di sini
// ============================================================

export const COMMUNITY_CONFIG = {
  // Identitas Komunitas
  name: "NovaCommunity",
  tagline: "Where Creators Collide",
  description:
    "Komunitas gaming dan kreator konten terbesar di Indonesia. Tempat berkumpulnya para gamer, streamer, dan content creator untuk berbagi, berkreasi, dan bertumbuh bersama.",
  shortBio:
    "Didirikan sejak 2021, NovaCommunity hadir sebagai ruang ekspresi bagi ribuan kreator dan gamer Indonesia. Kami percaya bahwa setiap orang punya cerita untuk dibagikan.",

  // Logo & Media (letakkan file di client/public/)
  logo: "/logo.svg",           // ganti dengan path logo kamu
  bannerImage: null,           // "/banner.jpg" atau null untuk gradient default
  heroVideo: null,             // "/hero-bg.mp4" atau null untuk gradient default

  // Statistik
  stats: [
    { value: "12K+", label: "Member Aktif", icon: "👥" },
    { value: "500+", label: "Konten Dibuat", icon: "🎬" },
    { value: "24/7", label: "Online Server", icon: "🌐" },
    { value: "#1", label: "Gaming Indo", icon: "🏆" },
  ],

  // Tag/Kategori Komunitas
  tags: ["Gaming", "Streaming", "Esports", "Content Creation", "Art", "Music"],

  // Social Links
  socials: {
    discord: "https://discord.gg/yourserver",   // ganti dengan link Discord kamu
    tiktok: "https://tiktok.com/@yourcommunity", // ganti dengan TikTok kamu
    youtube: "https://youtube.com/@yourcommunity",
    instagram: "https://instagram.com/yourcommunity",
    twitter: "https://twitter.com/yourcommunity",
  },

  // Tombol CTA Hero
  cta: {
    primary: {
      label: "Join Discord Server",
      href: "https://discord.gg/yourserver",
      icon: "discord",
    },
    secondary: {
      label: "Follow TikTok",
      href: "https://tiktok.com/@yourcommunity",
      icon: "tiktok",
    },
  },

  // Fitur / Keunggulan Komunitas
  features: [
    {
      icon: "🎮",
      title: "Gaming Events",
      desc: "Tournament dan event gaming mingguan dengan hadiah menarik untuk semua genre.",
    },
    {
      icon: "🎥",
      title: "Content Lab",
      desc: "Workshop dan mentoring untuk para kreator yang ingin level up konten mereka.",
    },
    {
      icon: "🤝",
      title: "Network Hub",
      desc: "Terhubung dengan ribuan gamer, streamer, dan kreator dari seluruh Indonesia.",
    },
    {
      icon: "🛡️",
      title: "Safe Space",
      desc: "Komunitas yang inklusif, positif, dan bebas dari toxicity. Semua selamat datang.",
    },
  ],

  // Footer
  footer: {
    copyright: "© 2025 NovaCommunity. All rights reserved.",
    tagline: "Made with ❤️ for the community",
  },
}

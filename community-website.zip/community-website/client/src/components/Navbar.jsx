import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { COMMUNITY_CONFIG } from '../config'

const NavIcon = () => (
  <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="logoGrad" x1="0" y1="0" x2="28" y2="28" gradientUnits="userSpaceOnUse">
        <stop stopColor="#7c3aed"/>
        <stop offset="1" stopColor="#06b6d4"/>
      </linearGradient>
    </defs>
    <polygon points="14,2 26,9 26,23 14,30 2,23 2,9" fill="url(#logoGrad)" opacity="0.9"/>
    <polygon points="14,6 22,11 22,21 14,26 6,21 6,11" fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="0.5"/>
    <text x="14" y="19" textAnchor="middle" fontSize="10" fontWeight="800" fontFamily="Syne,sans-serif" fill="white">N</text>
  </svg>
)

const DiscordIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.1 18.084.118 18.11.135 18.12a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
  </svg>
)

const MenuIcon = ({ open }) => (
  <div className="flex flex-col gap-1.5 w-5 cursor-pointer" aria-label="Menu">
    <span className={`block h-0.5 bg-white/80 rounded transition-all duration-300 ${open ? 'rotate-45 translate-y-2' : ''}`} />
    <span className={`block h-0.5 bg-white/80 rounded transition-all duration-300 ${open ? 'opacity-0' : ''}`} />
    <span className={`block h-0.5 bg-white/80 rounded transition-all duration-300 ${open ? '-rotate-45 -translate-y-2' : ''}`} />
  </div>
)

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setMobileOpen(false)
  }, [location])

  const navLinks = [
    { to: '/', label: 'Beranda' },
    { to: '/about', label: 'Tentang' },
    { to: '/gallery', label: 'Galeri' },
  ]

  const isActive = (to) => location.pathname === to

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-void/80 backdrop-blur-xl border-b border-glass-border'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <NavIcon />
              <span className="font-display font-bold text-lg tracking-tight text-white group-hover:text-gradient transition-all duration-300">
                {COMMUNITY_CONFIG.name}
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`nav-link ${isActive(link.to) ? 'active' : ''}`}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* CTA */}
            <div className="hidden md:flex items-center gap-3">
              <a
                href={COMMUNITY_CONFIG.socials.discord}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary flex items-center gap-2"
              >
                <DiscordIcon />
                <span>Join Server</span>
              </a>
            </div>

            {/* Mobile menu button */}
            <button
              className="md:hidden p-2"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle menu"
            >
              <MenuIcon open={mobileOpen} />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 md:hidden transition-all duration-500 ${
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div
          className="absolute inset-0 bg-void/95 backdrop-blur-2xl"
          onClick={() => setMobileOpen(false)}
        />
        <div
          className={`relative flex flex-col items-center justify-center h-full gap-8 transition-all duration-500 ${
            mobileOpen ? 'translate-y-0' : '-translate-y-8'
          }`}
        >
          {navLinks.map((link, i) => (
            <Link
              key={link.to}
              to={link.to}
              className={`font-display font-bold text-3xl tracking-tight transition-all duration-300 ${
                isActive(link.to) ? 'text-gradient' : 'text-white/80 hover:text-white'
              }`}
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              {link.label}
            </Link>
          ))}
          <a
            href={COMMUNITY_CONFIG.socials.discord}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary flex items-center gap-2 mt-4"
          >
            <DiscordIcon />
            <span>Join Discord Server</span>
          </a>
        </div>
      </div>
    </>
  )
}

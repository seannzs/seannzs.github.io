import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import NoiseOverlay from './components/NoiseOverlay'
import Home from './pages/Home'
import About from './pages/About'
import Gallery from './pages/Gallery'

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-void relative">
        <NoiseOverlay />
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/gallery" element={<Gallery />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  )
}
